Since PA-CEQ 3.0 is a major release revision, PA-CEQ 1.0-2.1 are not part of this ZIP file anymore.
I suggest you try PA-CEQ 3.0 for yourself and move to it if you like it. 

Old downloads of PA-CEQ 1-2.1 can be found here: https://github.com/GanstaKingofSA/PA-CEQ/releases/tag/2.1